﻿
$(document).ready(function () {
    $("#selectedschoolname").change(function () {
        //alert("selectedschoolname");
        //window.location = sContextPath + 'SchoolProfile/IndexSchoolProfile/Index/'+$(this).val();
        document.forms[0].submit();
    });

    $("#selectedschoolname2").change(function () {
        //alert("selectedschoolname2");
        //window.location = sContextPath + 'SchoolProfile/IndexSchoolProfile/Index/'+$(this).val();
        document.forms[0].submit();
    });
});